extends Control


const ROUND_SIZE := 8

const LEVELS = [
	{"name":"1 · First Roots", "tag":"Very easy", "desc":"Familiar roots and clues. No etymology knowledge needed."},
	{"name":"2 · Easy Clues", "tag":"Very easy +", "desc":"Simple prefixes and word parts you already meet every day."},
	{"name":"3 · Everyday Origins", "tag":"Easy", "desc":"Recognisable everyday words and straightforward histories."},
	{"name":"4 · English Foundations", "tag":"Easy +", "desc":"Old English and Germanic words hiding in plain sight."},
	{"name":"5 · Britain & Ireland", "tag":"Easy +", "desc":"Regional words and languages of Britain and Ireland."},
	{"name":"6 · Latin Around Us", "tag":"Developing", "desc":"Common Latin-derived words used in ordinary life."},
	{"name":"7 · Latin Roots", "tag":"Moderate", "desc":"Decode common Latin building blocks."},
	{"name":"8 · Greek Around Us", "tag":"Moderate", "desc":"Greek-derived elements in familiar modern vocabulary."},
	{"name":"9 · Greek Roots", "tag":"Moderate +", "desc":"Greek roots used in science, learning and everyday speech."},
	{"name":"10 · Word Families", "tag":"Intermediate", "desc":"Spot relationships between words and their shared roots."},
	{"name":"11 · Build the Word", "tag":"Intermediate", "desc":"Combine roots you have already met to decode whole words."},
	{"name":"12 · Borrowed Words", "tag":"Intermediate +", "desc":"Use word histories and clues to identify familiar English vocabulary."},
	{"name":"13 · Travelling Words", "tag":"Intermediate +", "desc":"Words borrowed into English from languages around the world."},
	{"name":"14 · Global Journeys", "tag":"Challenging", "desc":"Trace less obvious international word journeys."},
	{"name":"15 · Words That Changed", "tag":"Hard", "desc":"Words whose meanings shifted dramatically over time."},
	{"name":"16 · Meaning Shifters", "tag":"Hard +", "desc":"More semantic changes, broadenings, narrowings and metaphors."},
	{"name":"17 · Language Detective", "tag":"Very hard", "desc":"Use earlier knowledge to reason out unfamiliar meanings."},
	{"name":"18 · Deep Detective", "tag":"Expert", "desc":"Fewer giveaways: combine history, roots and context."},
	{"name":"19 · Etymology Master", "tag":"Master", "desc":"Historical forms, hidden compounds and difficult journeys."},
	{"name":"20 · Root Master", "tag":"Master +", "desc":"Obscure histories and careful deduction."},
	{"name":"21 · Hidden Histories", "tag":"Master +", "desc":"Unexpected histories hiding inside ordinary words."},
	{"name":"22 · Norse Footprints", "tag":"Expert +", "desc":"Old Norse influence on English and northern speech."},
	{"name":"23 · Celtic Threads", "tag":"Expert +", "desc":"Welsh, Gaelic, Irish and Cornish threads in the word story."},
	{"name":"24 · Hidden Routes", "tag":"Expert +", "desc":"Trace words reshaped as they travelled through other languages into English."},
	{"name":"25 · Science Roots", "tag":"Advanced", "desc":"Classical roots behind scientific and technical vocabulary."},
	{"name":"26 · Places & People", "tag":"Advanced", "desc":"Words born from names, places and historical associations."},
	{"name":"27 · Meaning Archaeology", "tag":"Advanced +", "desc":"Dig through surprising earlier meanings and semantic shifts."},
	{"name":"28 · Root Puzzles", "tag":"Expert puzzle", "desc":"Combine fragments and prior knowledge with fewer clues."},
	{"name":"29 · Deep Word Journeys", "tag":"Master puzzle", "desc":"Long borrowing chains and disguised histories."},
	{"name":"30 · Word Roots Grandmaster", "tag":"Grandmaster", "desc":"A demanding mixed challenge drawing on the whole course."}
]

const QUESTIONS = {
	0: [
		["bio", "life", "sound", "earth", "Greek bios means life.", "Biology is the study of living things."],
		["geo", "earth", "writing", "time", "Greek ge means earth or land.", "Geography describes the Earth."],
		["aqua", "water", "fire", "air", "Latin aqua means water.", "Aquatic means connected with water."],
		["tele", "far or distant", "small", "inside", "Greek tele means far off.", "A telescope lets us see distant objects."],
		["micro", "small", "many", "light", "Greek mikros means small.", "A microscope reveals very small things."],
		["photo", "light", "heat", "voice", "Greek phos/photos relates to light.", "Photography developed as drawing with light."],
		["chrono", "time", "colour", "movement", "Greek chronos means time.", "Chronology puts events in time order."],
		["aud", "hear", "see", "write", "Latin audire means to hear.", "An audience listens."],
		["port", "carry", "cut", "turn", "Latin portare means to carry.", "Transport carries something from place to place."],
		["dict", "say or speak", "sleep", "build", "Latin dicere means to say.", "Dictate originally involves saying words aloud."],
		["therm", "heat", "water", "shape", "Greek therme relates to heat.", "A thermometer measures temperature."],
		["tri", "three", "two", "ten", "Greek and Latin tri- conveys three.", "A triangle has three sides."]
	],
	2: [
		["manual", "connected with the hand", "connected with the sea", "connected with sleep", "Latin manus means hand.", "Manual work traditionally means work done by hand."],
		["pedestrian", "a person travelling on foot", "a person travelling by boat", "a person who writes", "Latin pes/pedis means foot.", "A pedestrian travels on foot."],
		["credible", "believable", "colourful", "breakable", "Latin credere means to believe or trust.", "A credible story can be believed."],
		["benefit", "something favourable or helpful", "something hidden", "something repeated", "Latin bene means well.", "A benefit is an advantage."],
		["telephone", "a device for sound over distance", "a device for measuring heat", "a device for writing by hand", "Greek tele means far and phone means sound or voice.", "Telephone combines two Greek-derived elements."],
		["photograph", "an image made using light", "a map of the sea", "a written law", "Photo relates to light and graph to writing/drawing.", "A photograph historically means a light-drawing."],
		["geography", "description or study of the Earth", "study of sound", "measurement of heat", "Geo means earth and graphy relates to writing or description.", "Geography concerns the Earth and its features."],
		["biology", "study of life", "study of numbers", "study of weather", "Bio means life and -logy denotes a field of study.", "Biology studies living things."],
		["transport", "carry across or from place to place", "write again", "look inside", "Trans- means across and port relates to carrying.", "Transport moves people or goods."],
		["audible", "able to be heard", "able to be seen", "able to be eaten", "Aud- relates to hearing.", "An audible sound can be heard."],
		["dictionary", "a reference work about words", "a book of maps", "a book of musical notes", "Dict- relates to saying or speaking; dictionary developed as a collection of words.", "A dictionary records words and meanings."],
		["microscope", "instrument for viewing very small things", "instrument for measuring distance", "instrument for hearing far away", "Micro means small and scope relates to looking.", "A microscope magnifies tiny objects."]
	],
	4: [
		["Bairn", "A child", "A stream", "A loaf", "Bairn means a child in Scots and northern English; it continues an old Germanic word.", "The bairn is playing outside."],
		["Cwtch", "A cuddle or cosy nook", "A steep hill", "A cooking pot", "Cwtch is strongly associated with Welsh and Welsh English; its deeper history is debated.", "Come here for a cwtch."],
		["Afon", "River", "Hill", "House", "Welsh afon means river and survives in many British river names.", "Afon appears in Welsh place names."],
		["Glen", "A narrow valley", "A harbour wall", "A market", "From Gaelic gleann, meaning a valley.", "They walked through the glen."],
		["Galore", "In abundance", "Very slowly", "Without warning", "English borrowed galore from Irish go leor, meaning enough or plenty.", "There were prizes galore."],
		["Yous", "Plural form of you", "Yesterday", "A pair of shoes", "Several English varieties developed yous after English lost the old thou/ye number distinction.", "Are yous coming along?"],
		["Wee", "Small", "Expensive", "Late", "Wee is long established in Scots and is also strongly associated with Northern Irish speech.", "Would you like a wee piece?"],
		["Ginnel", "A narrow passageway", "A young bird", "Heavy rain", "Ginnel is a long-standing northern English regional word.", "Take the ginnel between the houses."],
		["Mardy", "Sulky or grumpy", "Neatly dressed", "Quick to laugh", "Mardy is recorded especially in Midlands and northern English dialects.", "Don’t be mardy."],
		["Outwith", "Outside or beyond", "Alongside", "Before yesterday", "Outwith is a Scots and Scottish English word meaning outside or beyond.", "That is outwith our plans."],
		["Slogan", "A memorable rallying phrase", "A mountain path", "A drum", "Slogan comes from Scottish Gaelic sluagh-ghairm, a battle cry.", "The campaign adopted a slogan."],
		["Craic", "Fun, news or lively conversation", "A valley", "A coat", "Craic has a circular history: English/Scots crack passed into Irish and the Irish spelling later spread in English.", "What’s the craic?"]
	],
	6: [
		["manu", "hand", "foot", "head", "Latin manus means hand.", "Manual and manufacture preserve this root."],
		["ped", "foot", "eye", "mouth", "Latin pes/pedis means foot.", "Pedestrian belongs to this family."],
		["terr", "earth or land", "sky", "sea", "Latin terra means earth or land.", "Terrestrial means relating to land or Earth."],
		["voc", "voice or call", "measure", "join", "Latin vox/vocis relates to voice; vocare means to call.", "Vocal and vocation belong to this family."],
		["cred", "believe or trust", "break", "hide", "Latin credere means to believe or trust.", "Credible means believable."],
		["bene", "well or good", "before", "against", "Latin bene means well.", "Benefit carries a favourable sense."],
		["mal", "bad or ill", "large", "new", "Latin malus/male contributes the sense bad or badly.", "Malfunction means to function badly."],
		["inter", "between or among", "under", "after", "Latin inter means between or among.", "International literally points between nations."],
		["post", "after", "before", "inside", "Latin post means after.", "Postwar means after a war."],
		["semi", "half", "double", "many", "Latin semi means half.", "A semicircle is half a circle."],
		["omni", "all", "one", "none", "Latin omnis means all.", "Omnivorous combines the idea of all with eating."],
		["noct", "night", "day", "water", "Latin nox/noctis means night.", "Nocturnal animals are active at night."]
	],
	8: [
		["anthrop", "human", "star", "law", "Greek anthropos means human being.", "Anthropology studies humans."],
		["cardi", "heart", "skin", "bone", "Greek kardia means heart.", "Cardiology concerns the heart."],
		["derm", "skin", "blood", "mind", "Greek derma means skin.", "Dermatology concerns the skin."],
		["phon", "sound or voice", "shape", "number", "Greek phone means sound or voice.", "Phonetics studies speech sounds."],
		["log / logy", "word, account or field of study", "water", "circle", "Greek logos has senses including word, account and reason; -logy developed for fields of study.", "Geology is the study of Earth."],
		["astro", "star", "plant", "number", "Greek astron means star.", "Astronomy studies celestial objects."],
		["demo", "people", "king", "law", "Greek demos means people or populace.", "Democracy contains demo-."],
		["cracy", "power or rule", "writing", "trade", "Greek kratos means strength or power.", "Democracy and aristocracy use -cracy."],
		["mono", "one or single", "two", "many", "Greek monos means single or alone.", "A monologue is speech by one person."],
		["hyper", "over or excessive", "below", "equal", "Greek hyper means over, beyond or excessive.", "Hyperactive suggests unusually high activity."],
		["hypo", "under or below", "over", "around", "Greek hypo means under or below.", "Hypothermia is below-normal body temperature."],
		["scope", "look or examine", "carry", "speak", "Greek skopein means to look at or examine.", "Telescope and microscope share this element."]
	],
	10: [
		["If 'bio' = life and '-logy' = study, biology is…", "the study of life", "the measurement of land", "the writing of sound", "This combines two roots introduced earlier.", "Bio + logy gives biology."],
		["If 'geo' = earth and 'logy' = study, geology is…", "the study of the Earth", "the study of light", "the study of speech", "Geo + logy combines earth with study.", "Geology examines the Earth."],
		["If 'tele' = far and 'scope' = look, telescope is…", "an instrument for looking far away", "an instrument for measuring heat", "a book of maps", "Both roots appeared in earlier levels.", "Tele + scope gives telescope."],
		["If 'micro' = small and 'scope' = look, microscope is…", "an instrument for looking at small things", "an instrument for distant sound", "a device for carrying goods", "Micro + scope gives microscope.", "A microscope reveals tiny structures."],
		["If 'photo' = light and 'graph' = write/draw, photograph is…", "a picture made using light", "a spoken message", "a land measurement", "Photo + graph combines light with drawing/writing.", "The roots explain the older literal construction."],
		["If 'therm' = heat and 'meter' = measure, thermometer is…", "an instrument that measures temperature", "an instrument that measures distance", "a device that records sound", "The parts point to heat and measurement.", "Thermometers measure temperature."],
		["If 'mono' = one and 'logue' = speech, monologue is…", "a speech by one person", "a conversation between three people", "a silent performance", "The Greek-derived parts give one + speech.", "A monologue has one speaker."],
		["If 'inter' = between and 'national' relates to nations, international means…", "between or involving nations", "inside one household", "before a nation existed", "Inter- was introduced as between or among.", "International trade crosses national boundaries."],
		["If 'noct' = night, nocturnal means…", "active or occurring at night", "active only in water", "occurring every year", "Noct- was introduced as night.", "Owls are often described as nocturnal."],
		["If 'omni' = all and '-vorous' = eating, omnivorous means…", "eating many kinds of food", "eating only plants", "never eating", "Omni supplies the idea of all.", "Humans are commonly described as omnivorous."],
		["If 'tri' = three, trilogy contains…", "three related works", "two unrelated works", "ten short works", "Tri- was introduced in Level 1.", "A trilogy is a set of three works."],
		["If 'aud' = hear, inaudible means…", "unable to be heard", "unable to be seen", "easy to carry", "Aud- means hear; in- can negate.", "A whisper may become inaudible at a distance."]
	],
	12: [
		["Robot", "Czech", "Italian", "Arabic", "Robot entered English from Czech robot, popularised by Karel Čapek’s play R.U.R.; the word was suggested by his brother Josef.", "Robot became an international technology word."],
		["Piano", "Italian", "Welsh", "Hindi", "Piano is shortened from Italian pianoforte, describing an instrument capable of soft and loud playing.", "The shorter Italian form became standard in English."],
		["Algebra", "Arabic", "French", "Old Norse", "Algebra comes through Medieval Latin from Arabic al-jabr, used in the title of a mathematical work by al-Khwarizmi.", "English inherited a major mathematical term from Arabic scholarship."],
		["Shampoo", "Hindi/Urdu", "Greek", "Dutch", "Shampoo comes from a South Asian word related to pressing or massaging, entering English during British rule in India.", "Its English meaning later narrowed toward washing hair."],
		["Ketchup", "Probably from a Chinese-language source via Southeast Asian trade", "Latin", "Welsh", "Ketchup has a complex debated history, commonly linked to a Chinese term for a fermented sauce transmitted through maritime trade.", "The recipe changed greatly as the word travelled."],
		["Safari", "Swahili", "German", "Irish", "Safari comes from Swahili safari, journey, itself historically connected with Arabic safar.", "English borrowed it through East African travel contexts."],
		["Bungalow", "Hindi", "Greek", "Russian", "Bungalow comes from Hindi bangla, meaning in the Bengali style.", "The housing term travelled into global English."],
		["Café", "French", "Old English", "Welsh", "English borrowed café from French; the word ultimately traces through Italian to Arabic qahwa.", "One everyday word records several stages of borrowing."],
		["Kindergarten", "German", "Latin", "Irish", "Kindergarten is German for children’s garden.", "English borrowed the educational term directly."],
		["Tsunami", "Japanese", "Spanish", "Scots", "Tsunami is Japanese, combining elements meaning harbour and wave.", "The Japanese term became international."],
		["Patio", "Spanish", "Greek", "Old Norse", "English borrowed patio from Spanish.", "The word now commonly means an outdoor paved area."],
		["Pyjamas", "South Asian languages", "Welsh", "Finnish", "Pyjamas comes through Hindi/Urdu from Persian pay-jama, literally leg clothing.", "British English adopted the clothing term during contact with South Asia."]
	],
	14: [
		["Nice once meant something closer to…", "foolish or ignorant", "kind-hearted", "expensive", "Nice came through French from Latin nescius, ignorant, and shifted through several meanings before its modern favourable senses.", "Meaning can travel as dramatically as spelling."],
		["Awful originally meant…", "inspiring awe", "slightly annoying", "very small", "Awful was formed from awe + -ful and once meant full of or inspiring awe.", "Its dominant modern sense became strongly negative."],
		["Silly once had a sense closer to…", "blessed or fortunate", "angry", "silent", "Old English forms behind silly could mean happy, fortunate or blessed; later senses shifted toward innocence and foolishness.", "The modern meaning is far from the oldest senses."],
		["Meat in Old English could mean…", "food in general", "only beef", "a drink", "Old English mete could refer broadly to food.", "The modern word narrowed mainly to animal flesh used as food."],
		["Girl in Middle English could refer to…", "a young person of either sex", "only a daughter", "an elderly woman", "Early uses of girl could refer to a child or young person more generally.", "Its meaning later narrowed by sex and age."],
		["Deer in Old English could mean…", "animal in general", "only a stag", "forest", "Old English deor had the broad sense animal or beast.", "English later narrowed deer to the familiar animal group."],
		["Starve originally meant…", "to die", "to feel slightly hungry", "to preserve food", "Old English steorfan meant to die; the modern sense narrowed to dying or suffering from lack of food.", "Related Germanic languages preserve broader senses of dying."],
		["Manufacture originally points to…", "making by hand", "making only by machine", "selling overseas", "Latin manus is hand and facere is make; manufacture originally carried the idea of making by hand.", "Industrialisation changed the practical association of the word."],
		["Broadcast first referred to…", "scattering seed widely by hand", "speaking on radio", "sending letters abroad", "Broadcast was an agricultural term for scattering seed broadly.", "Radio and television later borrowed the metaphor."],
		["Mouse gained a new modern sense as…", "a computer pointing device", "a railway ticket", "a telephone call", "The computer device was named metaphorically after the small animal.", "Technology often creates new senses for old words."],
		["Cloud gained a computing sense meaning…", "remote networked computing/storage", "a paper notebook", "a type of keyboard", "Cloud was extended metaphorically from diagrams where a cloud represented an unspecified network.", "A weather word acquired a digital meaning."],
		["Tablet broadened in modern technology to mean…", "a flat portable computer", "a radio tower", "a camera lens", "Tablet long referred to flat slabs or writing surfaces before being applied to touchscreen computers.", "An old shape-based idea found a new technological use."]
	],
	16: [
		["You know 'tele' = far and 'phon' = sound. What would 'telephony' concern?", "transmitting sound over distance", "measuring body heat", "studying rocks", "Earlier levels supplied both roots; now you must combine them without seeing the familiar word telephone.", "Telephony concerns telephone communication."],
		["You know 'anthrop' = human and '-logy' = study. Anthropology is…", "the study of humans and societies", "the study of stars", "the study of skin", "Both elements were taught earlier.", "Anthropology studies humanity."],
		["With 'cardi' = heart, cardiomyopathy most likely concerns…", "disease of heart muscle", "disease of the skin", "measurement of sound", "Cardi- gives the strongest clue: heart. Myo- relates to muscle and -pathy to disease/suffering.", "The word can be partly decoded even if it is unfamiliar."],
		["With 'derm' = skin, hypodermic most likely means…", "under the skin", "above the clouds", "between nations", "Hypo- means under and derm- means skin.", "A hypodermic injection goes beneath the skin."],
		["With 'geo' = earth and 'thermal' = heat, geothermal energy comes from…", "heat from the Earth", "light from stars", "wind over water", "Both components were introduced earlier.", "Geothermal systems use heat from the Earth."],
		["If 'bene' = good/well and 'mal' = bad, which pair are opposites?", "beneficial and malicious", "manual and audible", "regional and national", "The roots bene- and mal- provide opposing clues.", "Root knowledge helps with unfamiliar vocabulary."],
		["If 'post' = after, a posthumous publication appears…", "after the author’s death", "before the author writes it", "during childhood", "Post- supplies the after clue; the rest of the word must be inferred from context.", "Some works are published posthumously."],
		["If 'inter' = between and 'personal' relates to people, interpersonal means…", "between people", "inside one person’s body", "before people existed", "Inter- retains its between/among sense.", "Interpersonal skills concern relations between people."],
		["A word ending in '-cracy' most likely names…", "a system of power or rule", "a musical instrument", "a unit of distance", "Level 5 introduced Greek kratos, power or rule.", "Democracy and aristocracy are examples."],
		["A word beginning 'noct-' most likely concerns…", "night", "water", "writing", "Level 4 introduced Latin nox/noctis, night.", "Noctilucent and nocturnal both contain the night element."],
		["If 'mono' = one and 'chrom' relates to colour, monochrome most likely means…", "using one colour or shades of one colour", "having many voices", "moving across countries", "Mono- gives the one clue; chrom- relates to colour.", "Monochrome images use a restricted colour range."],
		["If 'micro' = small and 'bio' = life, microbiology studies…", "microscopic life", "ancient stars", "large landforms", "Two Level 1 roots combine with -logy.", "Microbiology studies microorganisms."]
	],
	18: [
		["The English word 'window' comes from Old Norse vindauga, literally…", "wind-eye", "wall-hole", "light-door", "Old Norse vindauga combines windr, wind, and auga, eye.", "A familiar object hides an old compound."],
		["Wednesday preserves the name of which Germanic god?", "Woden/Odin", "Thor", "Tyr", "Old English Wodnesdæg means Woden’s day; Woden corresponds to Norse Odin.", "The modern spelling conceals the historical name."],
		["Goodbye developed from a contraction of…", "God be with ye", "good be your day", "go by the way", "Goodbye developed from forms of God be with ye/you.", "Its modern shape disguises a whole phrase."],
		["Candidate ultimately comes from Latin candidus, meaning…", "bright white", "clever", "elected", "Latin candidus means shining white; Roman office-seekers were associated with whitened togas.", "The political sense grew from that practice."],
		["Companion contains Latin panis, meaning…", "bread", "road", "friend", "Companion developed from the idea of one with whom bread is shared.", "Com- + panis underlies the history."],
		["Salary is historically connected with Latin sal, meaning…", "salt", "silver", "work", "Latin sal means salt. The exact history of salarium is more complicated than the popular claim that workers were simply paid in salt.", "Etymology sometimes corrects neat folk stories."],
		["Decimate historically referred to…", "killing or punishing one in ten", "dividing land into ten countries", "counting backwards from ten", "Latin decimare is connected with a tenth; modern decimate commonly means severe destruction.", "Historical and modern meanings can differ."],
		["Etymology contains Greek etymon, meaning…", "true sense or original form", "foreign sound", "short word", "Greek etymon means true sense, from etymos, true.", "The subject’s own name has an etymology."],
		["Whisky ultimately reflects a Gaelic phrase meaning…", "water of life", "grain of the hills", "fire drink", "Gaelic uisge beatha and Irish uisce beatha mean water of life, translating an older learned expression for distilled spirits.", "The phrase was shortened and reshaped in English."],
		["Slogan began as a Gaelic expression for…", "a battle cry", "a legal contract", "a harvest song", "Scottish Gaelic sluagh-ghairm referred to a host or army cry.", "Its meaning later broadened to memorable public phrases."],
		["Craic illustrates which kind of journey?", "English/Scots → Irish → English", "Latin → Japanese → English", "Welsh → French → English", "Crack in the sense talk/news passed into Irish as craic; the Irish spelling later became popular in English.", "Borrowing can travel in circles."],
		["River Avon contains an element that originally meant…", "river", "mountain", "bridge", "Welsh afon and related Brittonic forms mean river; English naming could treat the inherited element as a name.", "River Avon can effectively repeat the idea river."]
	],
	1: [
		["pre", "before", "after", "inside", "Latin prae means before.", "Preview means to view beforehand."],
		["sub", "under or below", "over", "between", "Latin sub means under or below.", "Submarine literally suggests under the sea."],
		["re", "again or back", "never", "half", "Latin re- commonly means again or back.", "Rewrite means write again."],
		["uni", "one", "two", "many", "Latin unus means one.", "A unicycle has one wheel."],
		["bi", "two", "three", "ten", "Latin bi- means two.", "A bicycle has two wheels."],
		["multi", "many", "one", "under", "Latin multus means much or many.", "Multicoloured means having many colours."],
		["anti", "against or opposed to", "before", "together", "Greek anti means against or opposite.", "Antifreeze works against freezing."],
		["auto", "self", "water", "night", "Greek autos means self.", "Autobiography is writing about one’s own life."],
		["super", "above or beyond", "under", "before", "Latin super means above or over.", "Superstructure is built above a base."],
		["trans", "across or beyond", "inside", "small", "Latin trans means across or beyond.", "Transatlantic means across the Atlantic."],
		["circum", "around", "through", "after", "Latin circum means around.", "Circumnavigate means travel around."],
		["cent", "hundred", "thousand", "half", "Latin centum means hundred.", "Century is a period of one hundred years."]
	],
	3: [
		["house", "a dwelling", "a road", "a tool", "Old English hus meant a dwelling or shelter.", "House belongs to the Germanic core of English."],
		["bread", "a baked food", "a river", "a garment", "Old English bread referred to a piece or morsel and later to bread.", "Bread is inherited rather than a recent borrowing."],
		["water", "the familiar liquid", "fire", "stone", "Old English wæter is Germanic and related to forms in other Germanic languages.", "Water is one of English’s oldest inherited words."],
		["mother", "a female parent", "a teacher", "a neighbour", "Old English modor belongs to an ancient Indo-European word family.", "Mother has relatives across many Indo-European languages."],
		["father", "a male parent", "a farmer", "a king", "Old English fæder is inherited from Germanic.", "Father has ancient relatives such as Latin pater."],
		["night", "the dark part of the day", "a season", "a colour", "Old English niht is an inherited Germanic word.", "Night has cognates in German Nacht and Dutch nacht."],
		["stone", "hard mineral matter", "a tree", "a field", "Old English stan is inherited Germanic vocabulary.", "Stone is related to German Stein."],
		["name", "a word identifying someone or something", "a number", "a promise", "Old English nama is inherited from Germanic.", "Name has relatives in German Name and Latin nomen."],
		["friend", "a person with whom one has affection", "an enemy", "a stranger", "Old English freond was related to a verb meaning love.", "Friend is native Old English vocabulary."],
		["king", "a male monarch", "a soldier", "a merchant", "Old English cyning meant king.", "King is inherited from Germanic English."],
		["work", "labour or activity", "sleep", "weather", "Old English weorc meant work or deed.", "Work has Germanic relatives."],
		["word", "a unit of language", "a road", "a song only", "Old English word is inherited Germanic vocabulary.", "Word has close relatives in other Germanic languages."]
	],
	5: [
		["annual", "yearly", "daily", "hourly", "Latin annus means year.", "Annual events happen every year."],
		["marine", "relating to the sea", "relating to mountains", "relating to fire", "Latin mare means sea.", "Marine biology studies life in the sea."],
		["lunar", "relating to the Moon", "relating to the Sun", "relating to rain", "Latin luna means Moon.", "A lunar eclipse involves the Moon."],
		["solar", "relating to the Sun", "relating to soil", "relating to sound", "Latin sol means Sun.", "Solar energy comes from sunlight."],
		["video", "connected with seeing or recorded images", "connected with taste", "connected with sleep", "Latin videre means to see.", "Video belongs to the same family as vision."],
		["scribe", "a writer or copyist", "a sailor", "a judge", "Latin scribere means to write.", "Describe and manuscript share related writing history."],
		["rupt", "break", "join", "hear", "Latin rumpere means to break.", "Rupture and interrupt contain this root family."],
		["ject", "throw", "sleep", "count", "Latin iacere/jacere means to throw.", "Reject and project developed from compounds using this root."],
		["spect", "look or see", "carry", "eat", "Latin specere relates to looking.", "Inspect and spectator share this family."],
		["form", "shape", "voice", "water", "Latin forma means form or shape.", "Transform means change form."],
		["tract", "draw or pull", "sing", "burn", "Latin trahere means to draw or pull.", "Attract and extract belong to this family."],
		["scrib / script", "write", "walk", "turn", "Latin scribere means to write.", "Script, inscription and describe are related."]
	],
	7: [
		["metre / meter", "measure", "light", "life", "Greek metron means measure.", "Thermometer combines heat with measure."],
		["cycle", "circle or wheel", "voice", "hand", "Greek kyklos means circle or wheel.", "Bicycle and cycle share this element."],
		["sym / syn", "together or with", "against", "before", "Greek syn means with or together.", "Symphony and synthesis preserve forms of this prefix."],
		["poly", "many", "one", "half", "Greek polys means many.", "Polygon and polyglot use poly-."],
		["mega", "great or large", "tiny", "hidden", "Greek megas means great or large.", "Megabyte uses mega- in a modern technical sense."],
		["neo", "new", "old", "below", "Greek neos means new.", "Neonatal means relating to a newborn."],
		["paleo", "ancient or old", "future", "small", "Greek palaios means ancient or old.", "Palaeontology studies ancient life."],
		["psych", "mind or soul", "skin", "earth", "Greek psyche means breath, soul or mind.", "Psychology uses this root family."],
		["theo", "god or deity", "river", "hand", "Greek theos means god.", "Theology is discourse or study concerning God or gods."],
		["morph", "form or shape", "sound", "number", "Greek morphe means form or shape.", "Morphology studies form and structure."],
		["path", "feeling, suffering or disease", "writing", "light", "Greek pathos relates to suffering, feeling or experience.", "Pathology and sympathy reflect different developments."],
		["arch", "chief, ruler or first", "water", "small", "Greek arche can mean beginning or rule; arch- can denote chief.", "Monarch contains a Greek-derived ruling element."]
	],
	9: [
		["vision and video share a root connected with…", "seeing", "hearing", "walking", "Both ultimately draw on Latin videre, to see.", "A shared root can survive in very different-looking words."],
		["manual and manufacture share a root meaning…", "hand", "machine", "money", "Both contain history connected with Latin manus, hand.", "Manufacture originally evokes making by hand."],
		["credible and credit share the idea of…", "belief or trust", "speed", "colour", "Both descend from Latin credere, to believe or trust.", "Credit historically depends on trust."],
		["vocal and vocation share history connected with…", "voice or calling", "water", "shape", "Latin vox is voice and vocare is to call.", "Vocation developed from the idea of a calling."],
		["pedal and pedestrian share a root meaning…", "foot", "road", "wheel", "Latin pes/pedis means foot.", "Pedal and pedestrian belong to the foot family."],
		["aquarium and aqueduct share…", "water", "air", "fire", "Latin aqua means water.", "An aqueduct carries water; an aquarium contains it."],
		["audience and audible share…", "hearing", "seeing", "writing", "Latin audire means to hear.", "Both words retain a hearing connection."],
		["portable and transport share…", "carrying", "cutting", "speaking", "Latin portare means to carry.", "Portable means able to be carried."],
		["describe and inscription share…", "writing", "eating", "sleeping", "Latin scribere means to write.", "The root changes shape across related words."],
		["spectator and inspect share…", "looking", "building", "counting", "Latin specere relates to looking.", "A spectator looks; to inspect is to look into closely."],
		["chronology and chronometer share…", "time", "distance", "weight", "Greek chronos means time.", "Both words concern time."],
		["geology and geography share…", "earth", "speech", "heat", "Greek ge means earth.", "Their endings tell you what is done with the earth-root."]
	],
	11: [
		["Which word entered English through Old French and is associated with administration and ruling?", "government", "ginnel", "tsunami", "Government entered English through Old French, ultimately from Latin.", "French became a major source of English administrative vocabulary."],
		["Which legal word entered Middle English through Old French and can mean the place where a judge hears cases?", "court", "cwtch", "safari", "Court entered Middle English through Old French.", "Law and government contain extensive French-derived vocabulary."],
		["Which legal word came through Old French from Latin roots and names the person who decides cases in court?", "judge", "bairn", "piano", "Judge came through Old French from Latin roots.", "The legal sense reflects Norman French influence."],
		["Which word for a group that decides facts in a trial entered English from Anglo-French/Old French?", "jury", "patio", "galore", "Jury entered English from Anglo-French/Old French.", "English legal vocabulary strongly reflects French."],
		["Which political word comes through French from parler, meaning 'to speak'?", "parliament", "kindergarten", "algebra", "Parliament comes through Anglo-French/Old French from parler, to speak.", "Its history is connected with speaking or discussion."],
		["Which food word came through Old French boef, while the animal name 'cow' remained Germanic?", "beef", "mutton", "bread", "Beef comes through Old French boef, from Latin bovem.", "English often kept Germanic animal names but borrowed French food terms."],
		["Which food word came from Old French porc, while 'pig' remained the Germanic animal name?", "pork", "beef", "fish", "Pork comes from Old French porc.", "Pig is Germanic; pork is French-derived."],
		["Which food word came from Old French moton, while 'sheep' remained Germanic?", "mutton", "pork", "milk", "Mutton came from Old French moton.", "Sheep is Germanic; mutton is French-derived."],
		["Which word for attractiveness or loveliness came into English through Old French?", "beauty", "slogan", "robot", "Beauty came through Old French.", "Many abstract and cultural terms entered via French."],
		["Which everyday word entered through French from Latin color?", "colour", "cloud", "craic", "Colour entered English through Anglo-French/Old French from Latin color.", "Its spelling and history reflect French transmission."],
		["Which adjective came through Old French from Latin regalis and contrasts historically with native 'kingly'?", "royal", "manual", "audible", "Royal came through Old French from Latin regalis.", "English has both native kingly and French-derived royal."],
		["Which word came through Old French from Latin libertas and overlaps in meaning with Germanic 'freedom'?", "liberty", "galore", "shampoo", "Liberty came through Old French from Latin libertas.", "English often has Germanic and Romance words with overlapping meanings."]
	],
	13: [
		["algebra", "Arabic", "Italian", "Welsh", "Algebra comes from Arabic al-jabr.", "It entered European scholarly vocabulary through Arabic mathematical tradition."],
		["zero", "Italian via Arabic tradition", "Old English", "Gaelic", "Zero entered English through Italian zero, connected with Arabic sifr.", "The word travelled with mathematical ideas."],
		["coffee", "Arabic via Turkish and European languages", "Old Norse", "Welsh", "Coffee has a long borrowing route involving Arabic qahwa and Turkish kahve.", "Trade helped spread both drink and word."],
		["yoghurt", "Turkish", "Latin", "Irish", "Yoghurt is borrowed from Turkish.", "Food words often travel with the foods themselves."],
		["avatar", "Sanskrit via Hindi and English", "Greek", "Old Norse", "Avatar ultimately comes from Sanskrit avatara, a descent or incarnation.", "English later extended the word to a digital representation of a person."],
		["jungle", "Hindi", "Welsh", "Latin", "Jungle entered English from Hindi jangal, ultimately from Sanskrit.", "Its English meaning developed toward dense tropical vegetation."],
		["pajamas / pyjamas", "Hindi/Urdu via Persian", "Old English", "Greek", "The word comes through Hindi/Urdu from Persian pay-jama, leg clothing.", "English spelling varies by region."],
		["ketchup", "probably from a Chinese-language source via Southeast Asian trade", "Latin", "Gaelic", "Ketchup has a debated but widely traced Asian trading history.", "Its recipe and meaning changed greatly in English."],
		["robot", "Czech", "French", "Arabic", "Robot comes from Czech robota, forced labour or drudgery.", "Karel Capek’s play helped internationalise the word."],
		["piano", "Italian", "Old Norse", "Welsh", "Piano is shortened from Italian pianoforte.", "The longer name contrasts soft and loud."],
		["mosquito", "Spanish", "Greek", "Old English", "Mosquito is borrowed from Spanish, where it is a diminutive of mosca, fly.", "The Spanish word became the English name for the insect."],
		["tsunami", "Japanese", "French", "Latin", "Tsunami is borrowed from Japanese, literally harbour wave.", "The Japanese term became international scientific and everyday vocabulary."]
	],
	15: [
		["awful once commonly meant…", "inspiring awe", "very small", "made of wood", "Awful originally had the sense full of awe or inspiring reverence/fear.", "Its dominant modern sense became strongly negative."],
		["terrific once strongly suggested…", "causing terror", "being ordinary", "being silent", "Terrific developed from terror and once meant causing terror.", "It later acquired the positive sense excellent."],
		["nice once had an early sense close to…", "foolish or ignorant", "kind and pleasant", "noisy", "Nice entered English from French with a sense derived from Latin nescius, ignorant.", "Its meaning shifted repeatedly before the modern positive sense."],
		["silly once could mean…", "happy, blessed or innocent", "angry", "expensive", "Old English sælig meant happy or blessed.", "The word travelled through senses such as innocent and pitiable to foolish."],
		["meat in Old English could mean…", "food in general", "only beef", "a drink", "Old English mete could mean food.", "Its meaning narrowed mainly to animal flesh."],
		["hound once had the broader meaning…", "dog", "horse", "bird", "Old English hund meant dog generally.", "Hound later narrowed to particular types of dog."],
		["holiday developed from…", "holy day", "hollow day", "whole day", "Holiday comes from holy day.", "The meaning broadened beyond specifically religious observance."],
		["thing in Old English could refer to…", "an assembly or matter for discussion", "only an object", "a weapon", "Old English þing could mean an assembly, meeting or matter.", "Its meaning broadened into the extremely general modern noun."],
		["broadcast moved from farming to…", "mass communication", "medicine", "law", "Broadcast first described scattering seed broadly.", "The metaphor was adopted by radio and later other media."],
		["viral expanded from medicine into…", "rapid online spread", "architecture", "navigation", "Viral originally relates to viruses.", "Digital culture extended it metaphorically to rapidly spreading content."],
		["stream expanded from flowing water into…", "continuous digital media delivery", "printing books", "measuring heat", "Stream has long meant a flow.", "Computing reused the flow metaphor for data and media."],
		["wall once meant a physical barrier; online it can also mean…", "a space displaying posts or messages", "a password", "a search engine", "Digital platforms extended the physical-surface metaphor.", "Old words regularly acquire technological senses."]
	],
	17: [
		["If 'circum' = around and 'spect' = look, circumspect suggests…", "looking around carefully; cautious", "speaking loudly", "moving underground", "The literal components suggest looking around.", "The modern adjective means wary or careful."],
		["If 'bene' = well and 'dict' = speak, benediction is…", "a blessing or expression of good wishes", "a legal punishment", "a measurement", "Latin bene plus dicere gives the history of speaking well.", "Benediction developed as a blessing."],
		["If 'mal' = bad and 'function' = perform, malfunction means…", "function badly or fail to work correctly", "work twice as fast", "become smaller", "Mal- supplies the bad/badly clue.", "A malfunction is faulty operation."],
		["If 'poly' = many and 'glot' = tongue/language, a polyglot is…", "someone using or knowing many languages", "a person with one job", "a mapmaker", "Greek-derived components give many + tongue/language.", "Polyglot can describe a multilingual person."],
		["If 'neo' = new and 'logism' concerns a word/expression, neologism is…", "a newly coined word or expression", "an ancient law", "a regional accent only", "Neo- supplies the new clue.", "Neologisms arise as language changes."],
		["If 'paleo' = ancient and 'lith' = stone, Palaeolithic means…", "ancient/old stone", "new writing", "many voices", "Greek roots combine old + stone.", "Palaeolithic is the Old Stone Age."],
		["If 'mono' = one and 'theism' concerns deity, monotheism means…", "belief in one God", "belief in many gods", "absence of language", "Mono- means one.", "The second element concerns deity or divinity."],
		["If 'sub' = under and 'terr' = earth, subterranean means…", "underground", "above the clouds", "across the sea", "Both roots provide direct clues.", "Subterranean literally points below the earth."],
		["If 'trans' = across and 'scribe' = write, transcribe means…", "write or copy across into another form", "destroy a text", "speak without writing", "The Latin compound combines across with writing.", "Transcribe means make a written copy or representation."],
		["If 'inter' = between and 'ject' = throw, interject historically suggests…", "throw in between", "carry away", "look backwards", "The Latin components are between + throw.", "To interject is to insert a remark."],
		["If 'circum' = around and 'navigate' = sail/travel, circumnavigate means…", "travel all the way around", "travel only north", "stay in one place", "The prefix supplies the around clue.", "Circumnavigation is a journey around something, especially the world."],
		["If 'omni' = all and 'scient' = knowing, omniscient means…", "all-knowing", "unable to hear", "half awake", "Latin omnis means all and scient- relates to knowing.", "Omniscient means knowing everything."]
	],
	19: [
		["Which familiar word ultimately contains Latin caput, head?", "capital", "aquatic", "audible", "Capital belongs to a complex family ultimately connected with Latin caput, head.", "Head can metaphorically become chief, principal or capital."],
		["Which word is related historically to Latin dexter, right-hand?", "dexterity", "dictionary", "density", "Dexter meant right or on the right side.", "Dexterity developed associations with right-handed skill."],
		["Sinister originally meant…", "left or on the left side", "honest", "bright", "Latin sinister meant left or on the left.", "Cultural associations helped produce its ominous English sense."],
		["Which English word comes from Greek schole, originally leisure?", "school", "scale", "shell", "Greek schole could mean leisure and then learned discussion/study.", "Its descendants eventually named places of instruction."],
		["Clue: Greek ostrakon was a potsherd. Which political word descends from it?", "ostracism", "optimism", "orchestra", "Athenians could write names on pottery fragments in a voting procedure.", "Ostracism developed from this historical practice."],
		["Which word ultimately reflects Latin rivalis, someone using the same stream?", "rival", "riverbank", "royal", "Rivalis was connected with rivus, stream.", "Competition over a shared stream contributed to the word’s history."],
		["Calculate comes from Latin calculus, originally…", "a small stone or pebble", "a written page", "a measuring rope", "Pebbles could be used in reckoning.", "A physical counting aid gave rise to mathematical vocabulary."],
		["Which word traces to Latin persona, associated with a theatrical role or character?", "person", "portion", "portal", "Persona was associated with a role or character and developed broader senses.", "The history ultimately feeds English person and personality."],
		["Muscle comes from Latin musculus, literally…", "little mouse", "little rope", "little bone", "Musculus is a diminutive of mus, mouse.", "The shape/movement of a muscle was compared with a little mouse."],
		["Which word comes from Greek galaxias, milky?", "galaxy", "geology", "gallery", "The Greek name referred to the Milky Way.", "Galaxy broadened to vast systems of stars."],
		["Disaster historically contains an element meaning…", "star", "water", "hand", "Disaster came through Italian/French from a formation involving astro, star, with a negative prefix.", "It reflects old astrological ideas of an unfavourable star."],
		["Which word ultimately comes from Greek planetes, wanderer?", "planet", "plant", "plate", "Planetes means wanderer.", "Planets appeared to wander against the fixed stars."]
	],
	20: [
		["salary is historically associated with Latin sal, meaning…", "salt", "silver", "grain", "Latin sal means salt; salarium is the source behind salary.", "Salary has a much older history than the modern pay packet."],
		["candidate ultimately comes from Latin candidus, meaning…", "white", "wise", "chosen", "Roman office-seekers were associated with a whitened toga.", "Candidate and candid share the idea of brightness/whiteness in their history."],
		["clue originally meant…", "a ball of thread", "a locked door", "a written law", "Clue is a variant of clew, a ball of thread.", "The thread that guides someone through a maze helped create the modern figurative sense."],
		["broadcast first described…", "scattering seed widely", "speaking loudly", "sending ships abroad", "Broad + cast was an agricultural expression for scattering seed.", "The word was later applied to radio and television transmission."],
		["deadline once referred literally to…", "a boundary that could not safely be crossed", "the final line of a newspaper", "a date on a calendar", "Deadline had a literal boundary sense before its modern time-limit sense.", "Today a deadline is the latest time for completion."],
		["window ultimately combines Old Norse words for…", "wind and eye", "wall and opening", "wood and glass", "Old Norse vindauga literally combines wind and eye.", "English window preserves a vivid Norse compound."],
		["companion ultimately contains a Latin idea of sharing…", "bread", "a road", "a house", "Companion traces through French to Latin elements meaning with + bread.", "A companion was historically someone with whom bread was shared."],
		["disclose once had the concrete sense of…", "opening or uncovering", "writing secretly", "closing a gate", "Disclose developed from a sense of unclosing or revealing.", "Its modern sense is to make information known."],
		["enthusiasm ultimately contains a Greek idea of…", "being inspired or possessed by a god", "speaking very softly", "measuring carefully", "Greek enthousiasmos was connected with divine inspiration.", "The modern word usually means intense eagerness."],
		["nice once had a meaning close to…", "foolish or ignorant", "friendly", "precise", "Nice travelled through several striking meaning changes.", "Its history shows that common adjectives can shift dramatically."],
		["quarantine is historically connected with the number…", "forty", "four", "fourteen", "Italian quaranta means forty; quarantine is tied to a forty-day period.", "The word later broadened to isolation for disease control."],
		["mortgage literally contains an old French idea of a…", "dead pledge", "house promise", "money road", "Mortgage came through French from elements meaning dead + pledge.", "The literal history is much less cheerful than the modern banking term."]
	],
	21: [
		["Old Norse sky originally referred more closely to a…", "cloud", "star", "storm", "Old Norse sky meant cloud; English later broadened the word to the heavens above.", "A familiar everyday word can hide a Norse semantic shift."],
		["Which everyday pronoun set is strongly associated with Old Norse influence?", "they / them / their", "I / me / my", "who / whom / whose", "English adopted they, them and their from Scandinavian forms.", "Even basic grammar carries traces of language contact."],
		["Old Norse knife is the ancestor of English…", "knife", "knave", "knit", "Knife comes from an Old Norse word of similar form.", "The silent k reflects later pronunciation change."],
		["Which word is of Old Norse origin and means anger?", "anger", "anxiety", "agony", "English anger comes from Old Norse angr.", "A core emotion word entered English through Scandinavian contact."],
		["Old Norse take helped replace or compete with which kind of native English vocabulary?", "older Germanic verbs", "Latin scientific terms", "Welsh place names", "Take is a major Norse contribution to ordinary English.", "Borrowing can affect the most basic parts of vocabulary."],
		["Which word meaning 'wrong' or 'ill' reflects Old Norse influence?", "wrong", "wicked", "false", "Wrong is from Old Norse rangr.", "The borrowing became a basic English adjective."],
		["Which northern English/Scots word meaning stream has Norse roots?", "beck", "burn", "brook", "Beck comes from Old Norse bekkr.", "It survives strongly in northern place names and regional speech."],
		["Which word for a steep narrow valley is strongly Norse in northern England?", "gill", "glen", "combe", "Gill in northern place names comes from Old Norse gil.", "Landscape vocabulary records settlement history."],
		["The -by in names such as Derby or Grimsby is Norse for…", "farmstead or village", "river crossing", "hilltop", "Old Norse byr means farmstead or settlement.", "The ending maps Scandinavian influence across parts of Britain."],
		["The -thorpe in many English place names points to a Norse…", "secondary settlement or village", "castle", "harbour", "Old Norse thorp referred to a settlement or outlying farm.", "Place-name elements can act like linguistic fossils."],
		["Which pair both entered English from Old Norse?", "egg and husband", "table and chair", "school and church", "Egg and husband are Scandinavian borrowings.", "Norse influence reaches deep into everyday vocabulary."],
		["The word law is strongly connected with Old Norse…", "lag", "lex", "loi", "English law comes from Old Norse lag.", "Legal vocabulary was also shaped by Scandinavian contact."]
	],
	22: [
		["Welsh cwm, borrowed into English geography, means…", "a valley or hollow", "a coastal island", "a stone wall", "Welsh cwm denotes a valley or hollow, especially in mountainous terrain.", "The word is used in British geographical vocabulary."],
		["Welsh hiraeth is difficult to translate exactly but often conveys…", "longing for home or something lost", "sudden anger", "formal celebration", "Hiraeth carries ideas of longing, homesickness and loss.", "Some culturally rich words resist a neat one-word translation."],
		["Scottish Gaelic loch means…", "lake or sea inlet", "mountain peak", "forest", "Loch is a Gaelic word familiar throughout Scotland and beyond.", "English uses loch especially for Scottish bodies of water."],
		["Gaelic glen refers to a…", "valley", "island", "harbour", "Glen comes from Gaelic gleann.", "It is common in Scottish place names and English usage about Scotland."],
		["Irish Gaelic slogan is historically linked to sluagh-ghairm, a…", "battle cry", "harvest song", "legal oath", "Slogan came through Gaelic from words for host/army and cry.", "A battle cry became a modern advertising or political phrase."],
		["Whisky ultimately comes from Gaelic words meaning…", "water of life", "grain fire", "golden drink", "Gaelic uisge beatha literally means water of life.", "The English form whisky developed from the Gaelic expression."],
		["Which Cornish word is widely known as a greeting meaning hello?", "dydh da", "cwtch", "braw", "Cornish dydh da literally means good day.", "Cornish is a revived Celtic language of Cornwall."],
		["The Welsh place-name element llan commonly refers historically to a…", "church or enclosure", "river", "market", "Llan is a very common Welsh place-name element tied to an enclosure and then church/parish.", "Place names preserve layers of Welsh linguistic history."],
		["Which word is Scots for a child and also has deep Germanic ancestry?", "bairn", "cwtch", "craic", "Bairn survives in Scots and northern English and goes back to Old English bearn.", "A regional word can preserve vocabulary lost from standard southern English."],
		["Ulster Scots is most closely related historically to…", "Scots", "Welsh", "Cornish", "Ulster Scots developed from Scots varieties brought to Ulster.", "Its history reflects migration and language contact across the North Channel."],
		["The element pen in many Celtic place names can mean…", "head or hill", "water", "wood", "Brittonic/Celtic pen means head and can extend to hill or summit.", "It survives in numerous place names."],
		["Which word associated with Welsh English means a cuddle or cosy safe place?", "cwtch", "gill", "bairn", "Cwtch is a Welsh word with affectionate modern senses.", "It is also used in Welsh English."]
	],
	23: [
		["English government came through French from a verb meaning…", "to steer or govern", "to count coins", "to build walls", "Government belongs to the enormous French/Latin layer of English.", "Norman and later French influence reshaped administration vocabulary."],
		["Which pair shows the classic English/French food distinction?", "cow / beef", "sheep / wool", "hen / egg", "Animal names often remained Germanic while elite food terms came through French.", "Cow is native Germanic; beef came through French."],
		["English court entered through French and ultimately relates to Latin for…", "an enclosed yard", "a written law", "a crown", "Court came through Old French from Latin cohors/cortem.", "A physical enclosure developed legal and royal senses."],
		["Which word entered English through French from Latin regal vocabulary?", "royal", "kingly", "queen", "Royal came through French; kingly is built from native Germanic material.", "English often has parallel French and Germanic word families."],
		["Liberty and freedom illustrate which pattern?", "French/Latin and Germanic near-synonyms", "two Welsh borrowings", "two Greek compounds", "Liberty came through French/Latin while freedom is Germanic.", "English vocabulary often layers words from different histories."],
		["Which word came through French and is related to Latin judex, judge?", "judge", "law", "wrong", "Judge entered Middle English through French.", "Legal English contains both French and Scandinavian/Germanic layers."],
		["English colour owes its spelling and route largely to…", "French", "Old Norse", "Welsh", "Colour came through Anglo-French/Old French from Latin.", "Its journey is visible in both form and spelling history."],
		["Which word came through French from a Latin word for head?", "chief", "hand", "foot", "Chief comes through French from Latin caput via later forms.", "It belongs to the same deep family as captain and capital."],
		["The English word mansion originally centred on the idea of…", "a dwelling or staying place", "a battlefield", "a market tax", "Mansion came through French from Latin mansio, a staying/dwelling.", "Its modern sense narrowed toward a large impressive house."],
		["Which pair ultimately shares a Latin root despite arriving in different forms?", "chief and capital", "house and hotel", "king and royal", "Chief and capital both trace back to Latin caput, head.", "Different borrowing routes can disguise family relationships."],
		["English parliament comes through French from parler, meaning…", "to speak", "to vote", "to rule", "Parliament is historically connected with speaking/discussion.", "Its word history reflects deliberation before the modern institution."],
		["Which native word roughly parallels French-derived commence?", "begin", "continue", "complete", "Begin is Germanic; commence entered through French.", "English often offers stylistic choices from different historical layers."]
	],
	24: [
		["The root cardio- relates to the…", "heart", "lung", "liver", "Greek kardia means heart.", "Cardiology is the study of the heart."],
		["Neuro- relates to…", "nerves", "bones", "blood", "Greek neuron gives the scientific element neuro-.", "Neurology concerns the nervous system."],
		["Osteo- means…", "bone", "muscle", "skin", "Greek osteon means bone.", "Osteology is the study of bones."],
		["Derm- or dermato- relates to…", "skin", "teeth", "eyes", "Greek derma means skin.", "Dermatology concerns skin."],
		["Haem-/hemat- relates to…", "blood", "air", "water", "Greek haima means blood.", "Haematology studies blood and blood disorders."],
		["The scientific prefix endo- means…", "within or inside", "outside", "around", "Greek endon means within.", "Endoskeleton describes an internal skeleton."],
		["The prefix exo- means…", "outside or external", "within", "below", "Greek exo means outside.", "An exoskeleton is an external supporting structure."],
		["The suffix -logy most directly signals…", "study or discourse", "measurement", "fear", "Greek logos developed many senses; -logy marks a field of study/discourse.", "Biology, geology and etymology use the suffix."],
		["The suffix -meter means an instrument for…", "measuring", "cutting", "hearing", "Greek metron means measure.", "Thermometer and barometer name measuring instruments."],
		["The root morph- means…", "form or shape", "sound", "time", "Greek morphe means form or shape.", "Morphology studies form and structure."],
		["The root path- in pathology relates to…", "suffering or disease", "movement", "light", "Greek pathos includes suffering/experience.", "Pathology concerns disease."],
		["The root glyc-/gluc- in scientific vocabulary relates to…", "sweet or sugar", "salt", "fat", "Greek glykys means sweet.", "Glucose belongs to this word family."]
	],
	25: [
		["A sandwich is named after…", "the Earl of Sandwich", "a town called Sandwich only", "a French chef", "The food name is traditionally associated with the 4th Earl of Sandwich.", "Personal names can become ordinary nouns."],
		["The word boycott comes from the surname of…", "Charles Boycott", "James Boycott", "Henry Boycott", "Boycott arose from the treatment of land agent Charles Boycott in Ireland.", "A person's surname became a verb and noun."],
		["Silhouette comes from the surname of a French…", "finance minister", "painter", "general", "The word is associated with Étienne de Silhouette.", "A proper name became a common word for an outline portrait."],
		["Diesel is named after…", "Rudolf Diesel", "Karl Benz", "James Watt", "The diesel engine takes its name from inventor Rudolf Diesel.", "Inventors frequently leave names embedded in vocabulary."],
		["The unit watt commemorates…", "James Watt", "Isaac Newton", "Michael Faraday", "Watt is named after engineer James Watt.", "Scientific units can preserve personal names."],
		["The unit newton commemorates…", "Isaac Newton", "James Joule", "Alessandro Volta", "The SI unit of force is named after Isaac Newton.", "A surname became a standard scientific unit."],
		["The word denim is traditionally linked to the French phrase meaning 'from' which city?", "Nîmes", "Paris", "Lyon", "Denim is commonly explained from serge de Nîmes, fabric from Nîmes.", "Place names can become material names."],
		["Champagne takes its name from…", "a region of France", "a grape variety", "a Roman emperor", "Champagne is named for the French region.", "Geographical names often become food and drink terms."],
		["The word marathon ultimately refers to…", "a place in Greece", "a Roman god", "a Persian title", "Marathon is named after the Greek place associated with the ancient battle and later race legend.", "A place name became a sporting distance."],
		["Which word comes from the name of an Italian voltage pioneer?", "volt", "ampere", "watt", "Volt commemorates Alessandro Volta.", "Scientific vocabulary often turns surnames into units."],
		["The word cardigan is named after…", "the Earl of Cardigan", "a Welsh town", "a knitting machine", "The garment name is associated with the 7th Earl of Cardigan.", "Titles and names can become clothing terms."],
		["Which term derives from the name of a Belgian instrument maker?", "saxophone", "telephone", "xylophone", "The saxophone is named after Adolphe Sax.", "Sax + Greek-derived -phone created the instrument name."]
	],
	26: [
		["Awful once meant something closer to…", "full of awe", "very bad", "slightly unpleasant", "Awful was formed from awe + -ful and once had a stronger sense of inspiring awe.", "Its dominant modern meaning shifted toward very bad."],
		["Artificial once could more neutrally mean…", "made with skill or art", "fake and dishonest", "electronic", "Artificial is related to artifice and making by skill.", "Modern usage often contrasts artificial with natural."],
		["Meat in Old English could refer broadly to…", "food", "only animal flesh", "a feast day", "Old English mete meant food more generally.", "The modern meaning narrowed to animal flesh."],
		["Deer in Old English could refer broadly to…", "an animal", "only a stag", "a hunting dog", "Old English deor meant animal/beast.", "Its meaning narrowed to the modern deer family."],
		["Girl in Middle English could at times refer to…", "a young person of either sex", "only an adult woman", "a servant only", "Early uses of girl were broader than the modern female-specific sense.", "The meaning later narrowed."],
		["Starve originally had a broader sense of…", "die", "feel hungry", "freeze", "Old English steorfan meant die.", "The meaning narrowed toward dying from hunger, then suffering extreme hunger."],
		["Manufacture literally reflects Latin roots for…", "making by hand", "making by machine", "selling in a market", "Manus means hand and facere means make/do.", "The modern word can describe large-scale machine production despite its roots."],
		["Computer once commonly referred to…", "a person who computes", "an electronic machine only", "a counting board", "Before electronic computers, a computer could be a person performing calculations.", "Technology shifted the usual referent from person to machine."],
		["Broadcast shifted from agriculture to…", "mass communication", "shipbuilding", "medicine", "Broadcast originally described scattering seed widely.", "Radio then television transformed its dominant sense."],
		["Mouse gained a technological sense because of…", "the computer device's resemblance to the animal", "an acronym", "a programmer's surname", "The computer mouse was named metaphorically for its shape and tail-like cable.", "A familiar animal word acquired a technical sense."],
		["Virus expanded from medicine/biology into computing through…", "metaphor", "a place name", "a person's surname", "Computer virus extends the idea of an infectious agent to malicious/self-replicating code.", "Technical language often borrows by metaphor."],
		["Cloud gained a computing sense based on…", "a metaphor for remote networked resources", "an ancient Greek root for data", "a hardware brand", "Network diagrams and abstraction helped cloud become a computing term.", "An old weather word acquired a modern technological meaning."]
	],
	27: [
		["If 'bene' means good and 'dict' means speak, benediction is most nearly…", "a blessing", "a contradiction", "a biography", "Latin bene + dicere gives the idea of speaking well/blessing.", "Previously learned roots can unlock an unfamiliar word."],
		["If 'mal' means bad and 'function' means perform, malfunction means…", "perform badly or fail to work", "work repeatedly", "work by hand", "The prefix mal- adds the idea of bad or faulty.", "Root knowledge can decode modern technical vocabulary."],
		["If 'circum' means around and 'navigate' concerns sailing/travel, circumnavigate means…", "travel around", "travel underground", "travel backwards", "Circum- means around.", "To circumnavigate is to travel all the way around something, especially the world."],
		["If 'poly' means many and 'glot' relates to tongue/language, a polyglot is…", "someone using many languages", "someone afraid of speech", "a writer of maps", "Greek-derived elements give many + tongue/language.", "The whole word can be inferred from its parts."],
		["If 'mono' means one and 'lith' means stone, a monolith is literally…", "one stone", "small stone", "moving stone", "Greek monos + lithos gives one stone.", "The word later developed broader figurative senses."],
		["If 'omni' means all and 'vor' relates to eating, omnivore means…", "an eater of many/all kinds of food", "a plant eater only", "a meat eater only", "Latin omnis + vorare gives the idea of eating all.", "Omnivore contrasts with herbivore and carnivore."],
		["If 'ante' means before and 'cedent' relates to going, antecedent is something that…", "goes or comes before", "comes after", "stands still", "Latin ante + cedere underlies antecedent.", "Its modern senses preserve the idea of preceding."],
		["If 'sub' means under and 'terr' means earth, subterranean means…", "under the ground", "across the sea", "above the clouds", "Latin sub + terra gives under earth.", "The roots directly reveal the meaning."],
		["If 'inter' means between and 'ject' means throw, interject is to…", "throw a remark into a conversation", "remove a statement", "write underneath", "Latin inter + jacere gives throw between.", "The figurative sense is to insert a remark."],
		["If 'retro' means backward and 'spect' means look, retrospect is…", "a look back", "a distant view", "a close inspection", "Latin-derived retro + specere gives look backward.", "Retrospect means reviewing the past."],
		["If 'trans' means across and 'luc' relates to light, translucent describes something that…", "lets light pass through partly", "blocks all light", "creates heat", "Latin trans + lucere helps explain translucent.", "The object transmits light without being fully transparent."],
		["If 'aqua' means water and 'duct' means lead, aqueduct is…", "a structure that carries water", "a device that measures rain", "a deep-water animal", "Latin aqua + ducere gives water + lead.", "An aqueduct conducts water from one place to another."]
	],
	28: [
		["English algebra travelled through Arabic from al-jabr. The initial al- is…", "the Arabic definite article", "a Greek negative prefix", "a Latin plural ending", "Arabic al- means the.", "Many Arabic loanwords preserve the article as part of the borrowed form."],
		["English admiral has a history involving Arabic amir, meaning…", "commander or prince", "sailor", "merchant", "Amir means commander/prince; the word's European journey altered its form.", "Borrowing can reshape both sound and spelling."],
		["English orange travelled through several languages; its deeper history is associated with…", "South Asian languages", "Old Norse", "Welsh", "Orange has a long borrowing chain through Persian/Arabic and European languages from an earlier South Asian source.", "Long-distance trade can leave complex linguistic trails."],
		["English sugar ultimately has a long trail back toward…", "Sanskrit", "Old English", "Gaelic", "Sugar travelled through multiple languages from an ancient South Asian source.", "Trade vocabulary often crosses many linguistic borders."],
		["English coffee reached English through forms associated with Arabic…", "qahwa", "kitab", "sukkar", "Coffee travelled via Turkish and European forms from Arabic qahwa.", "A global drink carried its name across languages."],
		["English chess ultimately has a historical connection with Persian shah, meaning…", "king", "horse", "board", "Chess vocabulary travelled from Persian through Arabic and European languages.", "Check and checkmate belong to the same historical game vocabulary."],
		["English zero entered through Italian from Arabic vocabulary ultimately linked to…", "empty", "one", "circle", "Zero's European history runs through Italian zero from Arabic sifr.", "The same Arabic source also contributed to cipher."],
		["Which pair has historically related routes through Arabic sifr?", "zero and cipher", "king and queen", "tea and coffee", "Arabic sifr, empty/zero, contributed through different routes to zero and cipher.", "Related borrowings can end up looking quite different."],
		["English magazine ultimately traces through French/Italian to Arabic makhazin, meaning…", "storehouses", "books", "weapons", "Arabic makhazin is the plural of a word for storehouse.", "The sense developed from a storehouse to a store of information and then a periodical."],
		["English tariff travelled through Italian/French from an Arabic word associated with…", "notification or list of fees", "a ship captain", "a market building", "Tariff has a Mediterranean borrowing history involving Arabic.", "Commercial contact helped carry the term into European languages."],
		["English lemon has a borrowing trail involving Arabic and Persian before reaching…", "European languages", "Old Norse only", "Welsh only", "Lemon travelled west with the fruit and trade.", "Names of foods often reveal trade routes."],
		["English safari entered through Swahili safari, which itself came from Arabic for…", "journey", "animal", "desert", "Swahili safari means journey and derives from Arabic safar.", "A word can be borrowed into one language and then borrowed again into another."]
	],
	29: [
		["Which word best demonstrates a native Germanic word surviving beside a French-derived synonym?", "freedom beside liberty", "telephone beside mobile", "river beside stream", "Freedom is Germanic while liberty came through French/Latin.", "English layers can offer near-synonyms with different histories."],
		["A word's etymology tells you…", "its historical origin and development, not necessarily its current meaning", "the only correct modern definition", "how it must be pronounced forever", "Etymology explains history; modern meaning is determined by usage.", "Historical roots inform meaning but do not dictate it."],
		["Which is the safest conclusion when two modern words look alike?", "similar spelling alone does not prove shared origin", "they must share a root", "one must be borrowed from the other", "False friends and coincidences make form alone unreliable.", "Good etymology needs historical evidence."],
		["A semantic narrowing occurs when a word…", "moves from a broad meaning to a more specific one", "becomes longer", "is borrowed from French", "Meat shifting from food generally to animal flesh is a classic narrowing pattern.", "Meaning change can alter scope without changing spelling much."],
		["A semantic broadening occurs when a word…", "develops a wider range of reference", "loses all figurative senses", "changes language", "Broadening expands the set of things a word can denote.", "Meaning histories can move in either direction."],
		["When a brand or proper name becomes a common word, the process involves…", "a proper name becoming lexicalised/generalised", "a prefix disappearing", "a plural becoming singular", "Names can become ordinary vocabulary through widespread usage.", "Eponyms show this process clearly."],
		["Which evidence is strongest for tracing a word's history?", "dated historical forms across texts and languages", "a modern spelling resemblance alone", "a popular story with no records", "Historical linguistics relies on attested forms, sound changes and documentary evidence.", "Plausible stories are not enough by themselves."],
		["If a borrowed word changes pronunciation after entering English, that is…", "normal linguistic adaptation", "proof the etymology is false", "necessarily a spelling error", "Borrowings are routinely adapted to the receiving language.", "Words rarely travel unchanged forever."],
		["Why can one English word have Germanic and Romance near-synonyms?", "English developed through prolonged contact and borrowing", "English was invented from Latin", "all Germanic words were translated later", "English history layered native vocabulary with Norse, French, Latin and other influences.", "The result is an unusually rich set of overlapping word choices."],
		["Which statement about 'original meaning' is most accurate?", "an older meaning does not invalidate later established meanings", "only the oldest meaning is correct", "modern dictionaries should ignore history", "Languages evolve through use.", "Etymology describes change rather than freezing words in their earliest sense."],
		["A calque is best described as…", "a loan translation built from native elements", "a word borrowed with identical spelling", "a random sound change", "Calques translate the parts of a foreign expression rather than borrowing its sound directly.", "Language contact can transfer patterns as well as words."],
		["The deepest skill Word Roots is testing here is…", "using evidence and learned roots to infer word history carefully", "memorising one dictionary definition", "guessing from spelling alone", "Advanced etymology combines forms, meanings, borrowing routes and sound history.", "Grandmaster reasoning should be cautious as well as clever."]
	]
}

var box: VBoxContainer
var deck: Array = []
var index := 0
var score := 0
var answered := false
var current_level := 0
var reports: Array = []
var save_ok := true
var saved_next_level := 0
const PROGRESS_FILE := "user://word_roots_progress.json"

func _ready():
	var theme_new = Theme.new()
	theme_new.default_font_size = 22
	for state in ["normal", "hover", "pressed", "disabled"]:
		var style = StyleBoxFlat.new()
		style.bg_color = Color("245b4b") if state != "disabled" else Color("344c43")
		style.border_color = Color("d7b76c")
		style.set_border_width_all(2)
		style.set_corner_radius_all(14)
		style.content_margin_left = 16
		style.content_margin_right = 16
		style.content_margin_top = 15
		style.content_margin_bottom = 15
		theme_new.set_stylebox(state, "Button", style)
	theme = theme_new
	var scroll = ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(scroll)
	var margin = MarginContainer.new()
	margin.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	scroll.add_child(margin)
	box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 17)
	margin.add_child(box)
	if FileAccess.file_exists("user://reports.json"):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string("user://reports.json"))
		if parsed is Array: reports = parsed
		else: save_ok = false
	load_progress()
	home()

func clear():
	for child in box.get_children():
		box.remove_child(child)
		child.queue_free()

func label_text(value: String, size := 22):
	var item = Label.new()
	item.text = value
	item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	item.add_theme_font_size_override("font_size", size)
	item.add_theme_color_override("font_color", Color("fff2d5"))
	box.add_child(item)
	return item

func button(value: String, callback: Callable):
	var item = Button.new()
	item.text = value
	item.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	item.custom_minimum_size.y = 66
	item.pressed.connect(callback)
	box.add_child(item)
	return item

func brand():
	label_text("BRAINY ELEPHANT", 19)
	label_text("Word Roots", 44)

func total_questions() -> int:
	var total := 0
	for level_questions in QUESTIONS.values():
		total += level_questions.size()
	return total


func load_progress():
	if FileAccess.file_exists(PROGRESS_FILE):
		var parsed = JSON.parse_string(FileAccess.get_file_as_string(PROGRESS_FILE))
		if parsed is Dictionary:
			saved_next_level = clamp(int(parsed.get("next_level", 0)), 0, LEVELS.size() - 1)

func save_progress():
	var next_level: int = mini(current_level + 1, LEVELS.size() - 1)
	saved_next_level = max(saved_next_level, next_level)
	var file = FileAccess.open(PROGRESS_FILE, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify({"next_level": saved_next_level, "last_completed_level": current_level, "last_score": score, "round_size": deck.size()}))
		file.close()
		show_saved_confirmation()

func show_saved_confirmation():
	label_text("✓ Progress saved on this device. Continue will return you to Level %d." % [saved_next_level + 1], 18)

func continue_progress():
	start(saved_next_level)

func home():
	clear()
	brand()
	label_text("How deep do your word roots go?", 27)
	label_text("Discover where words come from and how they evolve: roots, borrowed words, UK languages, regional speech and changing meanings.")
	if FileAccess.file_exists(PROGRESS_FILE):
		button("Continue from Level %d" % [saved_next_level + 1], continue_progress)
	button("Choose a knowledge level", level_select)
	button("Share a word", contribute)
	label_text("TESTER · 0.6 · %d questions\nThirty progressive knowledge levels. Every reveal teaches meaning, origin, evolution and usage." % total_questions(), 17)
	button("About Word Roots", about)

func level_select():
	clear()
	brand()
	label_text("Choose your level", 30)
	for i in range(LEVELS.size()):
		var level = LEVELS[i]
		button(level["name"] + "\n" + level["tag"], start.bind(i))
	button("Home", home)

func start(level_index: int):
	current_level = level_index
	deck = QUESTIONS[current_level].duplicate(true)
	deck.shuffle()
	deck = deck.slice(0, min(ROUND_SIZE, deck.size()))
	index = 0
	score = 0
	question()

func question():
	clear()
	answered = false
	brand()
	label_text("LEVEL %d / %d — %s" % [current_level + 1, LEVELS.size(), LEVELS[current_level]["name"].split(" · ", true, 1)[1].to_upper()], 25)
	label_text("QUESTION %d / %d     •     SCORE %d" % [index + 1, deck.size(), score], 18)
	var entry = deck[index]
	label_text(entry[0], 34)
	label_text("Choose the best answer", 22)
	var choices = [entry[1], entry[2], entry[3]]
	choices.shuffle()
	for choice in choices:
		button(choice, reveal.bind(choice))
	label_text("— navigation —", 15)
	button("← Choose another level", level_select)

func origin_info(entry: Array) -> Array:
	if entry.size() >= 9:
		return [entry[6], entry[7], entry[8]]
	var explanation: String = entry[4]
	var origin := "English word history"
	if "Greek" in explanation: origin = "Greek"
	elif "Latin" in explanation: origin = "Latin"
	elif "Old Norse" in explanation: origin = "Old Norse"
	elif "Old English" in explanation: origin = "Old English / Germanic"
	elif "French" in explanation: origin = "French / Latin"
	var journey := explanation
	var used := "Modern English; related forms may be international"
	return [origin, journey, used]

func feedback_panel(title: String, body: String, correct: bool):
	var panel = PanelContainer.new()
	var style = StyleBoxFlat.new()
	style.bg_color = Color("1f4d40") if correct else Color("4a3434")
	style.border_color = Color("d7b76c")
	style.set_border_width_all(3)
	style.set_corner_radius_all(16)
	style.content_margin_left = 18
	style.content_margin_right = 18
	style.content_margin_top = 16
	style.content_margin_bottom = 16
	panel.add_theme_stylebox_override("panel", style)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var inner = VBoxContainer.new()
	inner.add_theme_constant_override("separation", 8)
	panel.add_child(inner)
	var heading = Label.new()
	heading.text = title
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size", 28)
	heading.add_theme_color_override("font_color", Color("fff2d5"))
	inner.add_child(heading)
	var detail = Label.new()
	detail.text = body
	detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail.add_theme_font_size_override("font_size", 21)
	detail.add_theme_color_override("font_color", Color("fff2d5"))
	inner.add_child(detail)
	box.add_child(panel)
	return panel

func reveal(choice: String):
	if answered: return
	answered = true
	var entry = deck[index]
	var correct = choice == entry[1]
	if correct: score += 1
	clear()
	brand()
	var feedback_title = "✓ CORRECT!" if correct else "✗ NOT QUITE"
	var feedback_body = "Answer: " + entry[1]
	if not correct:
		feedback_body += "\nYour answer: " + choice
	feedback_panel(feedback_title, feedback_body, correct)
	label_text(entry[0], 32)
	label_text(entry[4], 20)
	label_text('“' + entry[5] + '”', 21)
	var history = origin_info(entry)
	label_text("WHERE DID IT COME FROM?", 18)
	label_text("Origin: " + history[0], 20)
	label_text("Journey: " + history[1], 19)
	label_text("Used in: " + history[2], 18)
	label_text("Score: %d" % score, 18)
	button("Next" if index < deck.size() - 1 else "See results", next_word)

func next_word():
	index += 1
	if index < deck.size():
		question()
	else:
		results()

func results():
	clear()
	brand()
	label_text("Roots growing", 30)
	label_text("%d / %d" % [score, deck.size()], 60)
	var message := "Keep exploring this level."
	if score == deck.size(): message = "Perfect round. Try the next level."
	elif score >= deck.size() - 1: message = "Excellent. You're ready to stretch further."
	elif score >= int(ceil(deck.size() * 0.75)): message = "Strong roots. One more round will reinforce them."
	label_text(message)
	if current_level < LEVELS.size() - 1:
		button("Next Level →", start.bind(current_level + 1))
	button("Save Progress", save_progress)
	button("Play this level again", start.bind(current_level))
	button("Choose another level", level_select)
	button("Home", home)

func field(title: String, initial := ""):
	label_text(title, 19)
	var edit = LineEdit.new()
	edit.text = initial
	edit.custom_minimum_size.y = 58
	box.add_child(edit)
	return edit

func contribute(word := ""):
	clear()
	brand()
	label_text("Share a word", 28)
	label_text("Saved on this device as a pending report. Nothing is uploaded or automatically added to the game.", 18)
	var word_field = field("Word or expression *", word)
	var meaning = field("Meaning in your own words *")
	var example = field("Your own example sentence *")
	var region = field("Language, region or origin (optional)")
	var consent = CheckBox.new()
	consent.text = "I wrote this and give permission\nto use and share my contribution."
	consent.add_theme_font_size_override("font_size", 18)
	box.add_child(consent)
	var status = label_text("%d reports saved on this device." % reports.size(), 18)
	button("Save pending report", func():
		if not save_ok:
			status.text = "Existing reports could not be read. They have been preserved."
			return
		if word_field.text.strip_edges().is_empty() or meaning.text.strip_edges().is_empty() or example.text.strip_edges().is_empty() or not consent.button_pressed:
			status.text = "Please fill all three required fields and confirm permission."
			return
		var report = {"word": word_field.text.strip_edges(), "meaning": meaning.text.strip_edges(), "example": example.text.strip_edges(), "region": region.text.strip_edges(), "date": Time.get_datetime_string_from_system(true), "consent": true, "status": "pending_local"}
		var updated = reports.duplicate()
		updated.append(report)
		var file = FileAccess.open("user://reports.tmp", FileAccess.WRITE)
		if file == null:
			status.text = "Could not save. Please try again."
			return
		file.store_string(JSON.stringify(updated))
		file.close()
		if DirAccess.rename_absolute("user://reports.tmp", "user://reports.json") != OK:
			status.text = "Could not finish saving. Please try again."
			return
		reports = updated
		status.text = "Saved on this device · pending. Thank you!"
		word_field.clear()
		meaning.clear()
		example.clear()
		region.clear()
		consent.button_pressed = false
	)
	button("Home", home)

func about():
	clear()
	brand()
	label_text("From local words to language history", 28)
	label_text("Word Roots begins with clues anyone can use, then steadily increases the difficulty across thirty levels. Earlier roots return in later challenges so the game teaches knowledge before asking you to reason with it.")
	label_text("This test library contains %d questions: 12 per level. Eight are selected at random for each round. Meaning, origin, word journey and modern usage are revealed as you learn." % total_questions(), 19)
	button("Home", home)
